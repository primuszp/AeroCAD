﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Primusz.Cadves.Core.Drawing;
using Primusz.Cadves.Core.Drawing.Entities;

namespace Primusz.Cadves.Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Loaded += (s, e) =>
            {
                Line line1 = new Line(new Point(0, 0), new Point(100, 100));
                Line line2 = new Line(new Point(100, 100), new Point(400, 100)) { Thickness = 3 };

                Layer layer1 = Viewport.CreateLayer("Layer 1");
                Layer layer2 = Viewport.CreateLayer("Layer 2");

                layer1.Color = Colors.Red;
                layer2.Color = Colors.Turquoise;

                layer1.Add(line1);
                layer2.Add(line2);
            };
        }
    }
}
