﻿using System.Windows;
using System.Windows.Input;
using Primusz.Cadves.Core.Drawing;

namespace Primusz.Cadves.Core.Tools
{
    public class PanZoomTool : BaseTool, IMouseListener
    {
        private Point startOffset;
        private Point startPoint;
        private double zoom = 1d;

        public PanZoomTool()
            : base("PanZoomTool")
        { }

        #region IMouseListener Members

        public void MouseButtonUp(MouseEventArgs e)
        {
            if (!IsActive) return;

            Viewport viewport = ToolService.Viewport as Viewport;

            if (viewport != null &&
                viewport.IsMouseCaptured)
            {
                viewport.Cursor = Cursors.Cross;
                viewport.ReleaseMouseCapture();
            }
        }

        public void MouseButtonDown(MouseEventArgs e)
        {
            if (!IsActive) return;

            Viewport viewport = ToolService.Viewport as Viewport;

            if (e.RightButton == MouseButtonState.Pressed)
            {
                startPoint = e.GetPosition(viewport);

                if (viewport != null)
                {
                    startOffset = new Point(viewport.Translate.X, viewport.Translate.Y);

                    viewport.CaptureMouse();
                    viewport.Cursor = Cursors.ScrollAll;
                }
            }
        }

        public void MouseMove(MouseEventArgs e)
        {
            if (!IsActive) return;

            Viewport viewport = ToolService.Viewport as Viewport;

            if (viewport != null &&
                viewport.IsMouseCaptured)
            {
                var currentPoint = e.GetPosition(viewport);
                viewport.Translate.X = currentPoint.X - startPoint.X + startOffset.X;
                viewport.Translate.Y = currentPoint.Y - startPoint.Y + startOffset.Y;
            }
        }

        public void MouseWheel(MouseWheelEventArgs e)
        {
            if (!IsActive) return;

            Viewport viewport = ToolService.Viewport as Viewport;

            zoom = viewport.Zoom;

            if (e.Delta > 0)
            {
                zoom *= 1.2d;

                if (zoom > 1000d)
                    zoom = 1000d;
            }
            else
            {
                zoom /= 1.2d;

                if (zoom < 0.001d)
                    zoom = 0.001d;
            }

            var scrPoint = e.GetPosition(viewport);
            var wrdPoint = viewport.ViewTransform.Inverse.Transform(scrPoint);

            viewport.Translate.X = -1 * (wrdPoint.X * zoom - scrPoint.X);
            viewport.Translate.Y = -1 * (wrdPoint.Y * zoom - scrPoint.Y);
            viewport.Scale.ScaleX = zoom;
            viewport.Scale.ScaleY = zoom;
            viewport.Zoom = zoom;
        }

        #endregion
    }
}
