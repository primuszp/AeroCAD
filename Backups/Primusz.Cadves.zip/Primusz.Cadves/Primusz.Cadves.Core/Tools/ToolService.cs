﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Primusz.Cadves.Core.Drawing;

namespace Primusz.Cadves.Core.Tools
{
    class ToolService : IToolService
    {
        #region Fields

        private Dictionary<Guid, ITool> tools;
        private readonly IServiceProvider provider;

        #endregion

        #region Constructors

        public ToolService(IServiceProvider provider, IViewport viewport)
        {
            this.provider = provider;
            Viewport = viewport;
            InitializeService();
        }

        #endregion

        #region Initialization

        private void InitializeService()
        {
            tools = new Dictionary<Guid, ITool>();

            Viewport.PreviewMouseRightButtonUp += MouseButtonUp;
            Viewport.PreviewMouseLeftButtonUp += MouseButtonUp;
            Viewport.PreviewMouseRightButtonDown += MouseButtonDown;
            Viewport.PreviewMouseLeftButtonDown += MouseButtonDown;
            Viewport.MouseWheel += MouseWheel;
            Viewport.MouseMove += MouseMove;
        }

        #region Input events binding

        private void MouseButtonDown(object sender, MouseButtonEventArgs e)
        {
            foreach (var listener in tools.Values.OfType<IMouseListener>())
            {
                listener.MouseButtonDown(e);
                if (e.Handled) return;
            }
        }

        private void MouseButtonUp(object sender, MouseButtonEventArgs e)
        {
            foreach (IMouseListener listener in tools.Values.OfType<IMouseListener>())
            {
                listener.MouseButtonUp(e);
                if (e.Handled) return;
            }
        }

        private void MouseWheel(object sender, MouseWheelEventArgs e)
        {
            foreach (IMouseListener listener in tools.Values.OfType<IMouseListener>())
            {
                listener.MouseWheel(e);
                if (e.Handled) return;
            }
        }

        private void MouseMove(object sender, MouseEventArgs e)
        {
            foreach (IMouseListener listener in tools.Values.OfType<IMouseListener>())
            {
                listener.MouseMove(e);
                if (e.Handled) return;
            }
        }

        #endregion

        #endregion

        #region IToolService Members

        public IViewport Viewport { get; private set; }

        public void RegisterTool(ITool tool)
        {
            if (tool == null) return;

            if (!tools.ContainsKey(tool.Id))
            {
                tools.Add(tool.Id, tool);
                tool.ToolService = this;
            }
        }

        public void UnregisterTool(ITool tool)
        {
            if (tool == null) return;

            if (tools.ContainsKey(tool.Id))
            {
                tools.Remove(tool.Id);
            }
        }

        public void SuspendAll()
        {
            foreach (ITool tool in tools.Values)
            {
                tool.IsSuspended = true;
            }
        }

        public void SuspendAll(ITool exclude)
        {
            foreach (ITool tool in tools.Values.Where(tool => tool.Id != exclude.Id))
            {
                tool.IsSuspended = true;
            }
        }

        public void UnsuspendAll()
        {
            foreach (ITool tool in tools.Values)
            {
                tool.IsSuspended = false;
            }
        }

        public ITool GetTool(Guid id)
        {
            return tools.ContainsKey(id) ? tools[id] : null;
        }

        public ITool GetTool(string name)
        {
            return tools.Values.FirstOrDefault(tool => tool.Name == name);
        }

        public bool ActivateTool(Guid id)
        {
            ITool tool = GetTool(id);
            return ActivateTool(tool);
        }

        public bool ActivateTool(ITool tool)
        {
            if (tool != null && tool.CanActivate)
                return tool.Activate();
            return false;
        }

        public bool DeactivateTool(ITool tool)
        {
            if (tool != null && tool.Enabled && tool.IsActive)
                return tool.Deactivate();
            return false;
        }

        public void DeactivateAll()
        {
            foreach (ITool tool in tools.Values)
            {
                tool.Deactivate();
            }
        }

        #endregion

        #region IServiceProvider Members

        public object GetService(Type serviceType)
        {
            return provider.GetService(serviceType);
        }

        #endregion
    }
}
