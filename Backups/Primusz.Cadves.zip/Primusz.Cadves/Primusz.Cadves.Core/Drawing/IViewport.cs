﻿using System;
using System.Windows;

namespace Primusz.Cadves.Core.Drawing
{
    public interface IViewport : IInputElement
    {
    }
}
