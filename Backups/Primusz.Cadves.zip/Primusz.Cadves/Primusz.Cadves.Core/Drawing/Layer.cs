﻿using System;
using System.Windows;
using System.Collections;
using System.Windows.Media;
using Primusz.Cadves.Core.Drawing.Entities;

namespace Primusz.Cadves.Core.Drawing
{
    public class Layer : VisualHost
    {
        #region Members

        private Brush brush;
        private Color color;

        #endregion

        #region Properties

        public Guid Id { get; private set; }

        public string LayerName { get; set; }

        public Color Color
        {
            get { return color; }
            set
            {
                if (value != color)
                {
                    color = value;
                    brush = new SolidColorBrush(color);
                    UpdateDrawingEntities();
                }
            }
        }

        public IList Selected { get; private set; }

        #endregion

        public Layer()
        {
            Id = Guid.NewGuid();
            Color = Colors.White;
            Selected = new ArrayList();
        }

        public void Add(Entity entity)
        {
            entity.UpdateDrawing(brush, Viewport.ViewTransform);
            AddVisualChildToCollection(entity);
        }

        public void Clear()
        {
            Visuals.Clear();
        }

        private void UpdateDrawingEntities()
        {
            foreach (Visual visual in Visuals)
            {
                if (visual is Entity)
                {
                    Entity entity = visual as Entity;
                    entity.UpdateDrawing(brush, Viewport.ViewTransform);
                }
            }
        }

        public void HitTest(Point point)
        {
            HitTest(null, new PointHitTestParameters(point));
        }

        public void HitTest(Rect rect)
        {
            HitTest(null, new GeometryHitTestParameters(new RectangleGeometry(rect)));
        }

        // See: http://stackoverflow.com/questions/14832037/wpf-hit-testing-a-rectangular-area
        public void HitTest(RectangleGeometry rect)
        {
            HitTest(null, new GeometryHitTestParameters(rect));
        }

        private void HitTest(HitTestFilterCallback hitTestFilterCallback, HitTestParameters parameters)
        {
            // Clear the contents of the list used for hit test results.
            Selected.Clear();

            // Set up a callback to receive the hit test result enumeration.
            VisualTreeHelper.HitTest(this, hitTestFilterCallback, HitTestResult, parameters);

            // Perform actions on the hit test results list.
            if (Selected.Count > 0)
            {
                ;
            }
        }

        // Return the result of the hit test to the callback.
        private HitTestResultBehavior HitTestResult(HitTestResult result)
        {
            // Add the hit test result to the list that will be processed after the enumeration.
            Selected.Add(result.VisualHit);

            // Set the behavior to return visuals at all z-order levels.
            return HitTestResultBehavior.Continue;
        }
    }
}
