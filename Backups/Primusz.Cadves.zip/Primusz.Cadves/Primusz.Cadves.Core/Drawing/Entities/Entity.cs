﻿using System;
using System.Windows;
using System.Windows.Media;
using Primusz.Cadves.Core.Drawing.Handles;

namespace Primusz.Cadves.Core.Drawing.Entities
{
    public abstract class Entity : DrawingVisual
    {
        public double Thickness { get; set; }

        protected Entity()
        {
            Thickness = 1.0;
        }

        public abstract void UpdateDrawing(Brush brush, Transform transform = null);

        public abstract GripList GetGrips();

        /// <summary>
        /// Get grip point by index
        /// </summary>
        public abstract Point GetGripPoint(int index);
    }
}
