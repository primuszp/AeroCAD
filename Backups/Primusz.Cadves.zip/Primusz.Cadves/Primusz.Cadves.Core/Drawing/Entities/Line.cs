﻿using System;
using System.Windows;
using System.Windows.Media;
using Primusz.Cadves.Core.Drawing.Handles;

namespace Primusz.Cadves.Core.Drawing.Entities
{
    public class Line : Entity
    {
        public Point StartPoint { get; set; }

        public Point EndPoint { get; set; }

        public Line(Point start, Point end)
        {
            StartPoint = start;
            EndPoint = end;
        }

        public override GripList GetGrips()
        {
            GripList grips = new GripList
            {
                new Grip(this, 0), 
                new Grip(this, 1)
            };

            return grips;
        }

        /// <summary>
        /// Get grip point by index
        /// </summary>
        public override Point GetGripPoint(int index)
        {
            return index == 0 ? StartPoint : EndPoint;
        }

        public override void UpdateDrawing(Brush brush, Transform transform = null)
        {
            using (DrawingContext dc = RenderOpen())
            {
                LineGeometry lg = new LineGeometry(StartPoint, EndPoint);

                if (transform != null)
                {
                    lg.Transform = transform;
                }

                dc.DrawGeometry(null, new Pen(brush, Thickness), lg);
            }
        }
    }
}