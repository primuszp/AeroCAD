﻿using System;
using System.Windows;
using System.Windows.Media;

namespace Primusz.Cadves.Core.Drawing
{
    public class VisualHost : FrameworkElement
    {
        public VisualCollection Visuals;

        public Viewport Viewport
        {
            get { return Parent as Viewport; }
        }

        public VisualHost()
        {
            Visuals = new VisualCollection(this);
        }

        public void AddVisualChildToCollection(Visual visual)
        {
            Visuals.Add(visual);
        }

        protected override int VisualChildrenCount
        {
            get { return Visuals.Count; }
        }

        protected override Visual GetVisualChild(int index)
        {
            if (index < 0 || index >= Visuals.Count)
            {
                throw new ArgumentOutOfRangeException();
            }
            return Visuals[index];
        }
    }
}