﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Primusz.Cadves.Core.Drawing.Entities;
using Primusz.Cadves.Core.Drawing.Handles;

namespace Primusz.Cadves.Core.Drawing
{
    public class Viewport : Canvas, IViewport
    {
        #region Members

        private IList<Layer> layers = new List<Layer>();

        private Point startOffset;
        private Point startPoint;
        private Point position;

        #endregion

        #region Properties

        public static readonly DependencyProperty PropertyTypeProperty = DependencyProperty.Register(
            "PropertyType", typeof (TranslateTransform), typeof (Viewport), new PropertyMetadata(default(TranslateTransform)));

        public TranslateTransform Translate
        {
            get { return (TranslateTransform) GetValue(PropertyTypeProperty); }
            set { SetValue(PropertyTypeProperty, value); }
        }

        public static readonly DependencyProperty ScaleTransformProperty = DependencyProperty.Register(
            "ScaleTransform", typeof (ScaleTransform), typeof (Viewport), new PropertyMetadata(default(ScaleTransform)));

        public ScaleTransform Scale
        {
            get { return (ScaleTransform) GetValue(ScaleTransformProperty); }
            set { SetValue(ScaleTransformProperty, value); }
        }

        public static readonly DependencyProperty ViewTransformProperty = DependencyProperty.Register(
            "ViewTransform", typeof(TransformGroup), typeof(Viewport), new PropertyMetadata(default(TransformGroup)));

        public TransformGroup ViewTransform
        {
            get { return (TransformGroup)GetValue(ViewTransformProperty); }
            set { SetValue(ViewTransformProperty, value); }
        }

        public static readonly DependencyProperty ZoomProperty = DependencyProperty.Register(
            "Zoom", typeof(double), typeof(Viewport), new PropertyMetadata(default(double)));

        public double Zoom
        {
            get { return (double)GetValue(ZoomProperty); }
            set { SetValue(ZoomProperty, value); }
        }

        public static readonly DependencyProperty PositionProperty = DependencyProperty.Register(
            "Position", typeof(Point), typeof(Viewport), new PropertyMetadata(default(Point)));

        public Point Position
        {
            get { return (Point)GetValue(PositionProperty); }
            set { SetValue(PositionProperty, value); }
        }

        #endregion

        Layer overlay = new Layer();
        GripList grips = new GripList();

        public Viewport()
        {
            ClipToBounds = true;
            Children.Add(overlay);
            SetZIndex(overlay, 100);

            LayoutTransform = new ScaleTransform() { ScaleX = 1, ScaleY = -1 };

            Scale = new ScaleTransform();
            Translate = new TranslateTransform();

            ViewTransform = new TransformGroup();
            {
                ViewTransform.Children.Add(Scale);
                ViewTransform.Children.Add(Translate);
            }
        }

        public Layer CreateLayer(string name)
        {
            Layer layer = new Layer { LayerName = name };
            Children.Add(layer);
            SetZIndex(layer, Children.Count);

            return layer;
        }

        /// <summary>
        /// Projects a point from object space into screen space. 
        /// </summary>
        /// <param name="point">World point</param>
        /// <returns></returns>
        public Point Project(Point point)
        {
            return ViewTransform.Transform(point);
        }

        /// <summary>
        /// Converts a screen space point into a corresponding point in world space. 
        /// </summary>
        /// <param name="point">Scree point</param>
        /// <returns></returns>
        public Point Unproject(Point point)
        {
            var inverse = ViewTransform.Inverse;
            return inverse != null ? inverse.Transform(point) : new Point();
        }

        #region Override Mouse Events

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            GeneralTransform inverse = ViewTransform.Inverse;

            if (inverse != null)
            {
                Position = inverse.Transform(e.GetPosition(this));

                if (IsMouseCaptured)
                {
                    var currentPoint = e.GetPosition(this);
                    Translate.X = currentPoint.X - startPoint.X + startOffset.X;
                    Translate.Y = currentPoint.Y - startPoint.Y + startOffset.Y;

                    UpdateOverlay();
                }
            }
        }

        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            base.OnMouseWheel(e);

            if (e.Delta > 0)
            {
                Zoom *= 1.2d;

                if (Zoom >= 1000d)
                {
                    Zoom = 1000d;
                }
            }
            else
            {
                Zoom /= 1.2d;

                if (Zoom <= 0.001d)
                {
                    Zoom = 0.001d;
                }
            }

            GeneralTransform inverse = ViewTransform.Inverse;

            if (inverse != null)
            {
                var scrPoint = e.GetPosition(this);
                var wrdPoint = inverse.Transform(scrPoint);

                Translate.X = -1d * (wrdPoint.X * Zoom - scrPoint.X);
                Translate.Y = -1d * (wrdPoint.Y * Zoom - scrPoint.Y);
                Scale.ScaleX = Zoom;
                Scale.ScaleY = Zoom;
            }

            UpdateOverlay();
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            {
                if (e.RightButton == MouseButtonState.Pressed)
                {
                    startPoint = e.GetPosition(this);
                    startOffset = new Point(Translate.X, Translate.Y);

                    CaptureMouse();
                    Cursor = Cursors.ScrollAll;
                }

                //foreach (var child in Children)
                //{
                //    if (child is Layer)
                //    {
                //        Layer layer = child as Layer;
                //        Point point = e.GetPosition(this);
                //        layer.HitTest(point);
                //    }
                //}
            }
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
            {
                if (IsMouseCaptured)
                {
                    Cursor = Cursors.Cross;
                    ReleaseMouseCapture();
                }
            }
        }

        protected override void OnMouseRightButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseRightButtonDown(e);
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            {

            }
        }

        protected override void OnMouseRightButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseRightButtonUp(e);
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
        }

        #endregion

        private void UpdateOverlay()
        {
            overlay.Clear();

            if (grips.Count == 0)
            {
                foreach (var child in Children)
                {
                    if (child is Layer)
                    {
                        Layer layer = child as Layer;

                        foreach (var visual in layer.Visuals)
                        {
                            Line line = visual as Line;

                            grips.AddRange(line.GetGrips());
                        }
                    }
                }
            }

            grips.Draw(Project);

            foreach (Grip grip in grips)
            {
                overlay.Visuals.Add(grip);
            }
        }
    }
}
